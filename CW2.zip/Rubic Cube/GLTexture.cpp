#include "stdafx.h"
#include "GLTexture.h"

BOOL GLTexture::PowerOfTwo(int n)
{
	if (n <= 0)
		return FALSE;
	return (n & (n - 1)) == 0;
}

GLuint GLTexture::LoadTexture(const char* file_name)
{
	GLint width, height, total_bytes;
	GLubyte* pixels = 0;
	GLuint last_texture_ID = 0, texture_ID = 0;
	FILE* pFile;
	errno_t err;

	// Open the file and return if it fails
	if ((err = fopen_s(&pFile, file_name, "rb")) != 0)
	{
		printf("�޷��򿪴��ļ�\n");            // If it doesn't open, the output won't open
		exit(0);                            // Termination procedure
	}

	// Read the width and height of the image in the file
	fseek(pFile, 0x0012, SEEK_SET);
	fread(&width, 4, 1, pFile);
	fread(&height, 4, 1, pFile);
	fseek(pFile, BMP_Header_Length, SEEK_SET);

	// Calculates the number of bytes per row of pixels, and calculates the total number of pixel bytes based on this data
	{
		GLint line_bytes = width * 3;
		while (line_bytes % 4 != 0)
			++line_bytes;
		total_bytes = line_bytes * height;
	}

	// Memory is allocated according to the total number of pixel bytes
	pixels = (GLubyte*)malloc(total_bytes);
	if (pixels == 0)
	{
		fclose(pFile);
		return 0;
	}

	// Read pixel data
	if (fread(pixels, total_bytes, 1, pFile) <= 0)
	{
		free(pixels);
		fclose(pFile);
		return 0;
	}

	// For compatibility with older versions, scaling is required if the width and height of the image are not raised to integer powers
	// If the width and height of the image exceed the maximum value specified by OpenGL, it is also scaled
	{
		GLint max;
		glGetIntegerv(GL_MAX_TEXTURE_SIZE, &max);
		if (!PowerOfTwo(width)
			|| !PowerOfTwo(height)
			|| width > max
			|| height > max)
		{
			const GLint new_width = 256;
			const GLint new_height = 256; // Specifies that the new size of the scaled square is the length of the side
			GLint new_line_bytes, new_total_bytes;
			GLubyte* new_pixels = 0;

			// Calculate the number of bytes required per line and the total number of bytes
			new_line_bytes = new_width * 3;
			while (new_line_bytes % 4 != 0)
				++new_line_bytes;
			new_total_bytes = new_line_bytes * new_height;

			// Allocate memory
			new_pixels = (GLubyte*)malloc(new_total_bytes);
			if (new_pixels == 0)
			{
				free(pixels);
				fclose(pFile);
				return 0;
			}

			// Pixel scale
			gluScaleImage(GL_RGB,
				width, height, GL_UNSIGNED_BYTE, pixels,
				new_width, new_height, GL_UNSIGNED_BYTE, new_pixels);

			// Release the original pixel data, point pixels to the new pixel data, and reset the width and height
			free(pixels);
			pixels = new_pixels;
			width = new_width;
			height = new_height;
		}
	}

	// Assign a new texture number
	glGenTextures(1, &texture_ID);
	if (texture_ID == 0)
	{
		free(pixels);
		fclose(pFile);
		return 0;
	}

	// Bind the new texture, load the texture and set the texture parameters
	// Before binding, the texture number of the original binding is obtained so that it can be restored at the end
	GLint lastTextureID = last_texture_ID;
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &lastTextureID);
	glBindTexture(GL_TEXTURE_2D, texture_ID);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0,
		GL_BGR_EXT, GL_UNSIGNED_BYTE, pixels);
	glBindTexture(GL_TEXTURE_2D, lastTextureID);  //Restore previous texture bindings
	free(pixels);
	return texture_ID;
}
